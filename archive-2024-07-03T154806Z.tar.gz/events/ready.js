const Discord = require("discord.js");
const db = require("croxydb");

// Kullanıcının son tag komutu kullanma zamanını saklamak için bir obje
const tagCooldowns = {};
const allCooldowns = {}; // Kullanıcının son -all komutu kullanma zamanını saklamak için bir obje

module.exports = {
name: 'ready',



run: async (client) => {	
    console.log(`${client.user.tag} Aktif!`);
    const activities = ["NETTR | net.tr"];

    // Bot aktif olduğunda log kanalı
    const activityLogChannel = client.channels.cache.get('1252923177386905601'); // Bot aktiflik log kanalının ID'si
    if (activityLogChannel) {
        activityLogChannel.send(`<:tik:1246412431882850334> Şuanda ${client.user.tag} Aktif!`);
    } else {
        console.error("Aktiflik log kanalı bulunamadı!");
    }

    setInterval(async () => {
        const randomActivity = activities[Math.floor(Math.random() * activities.length)];
        client.user.setActivity(randomActivity); // Sadece özel durumu ayarla
    }, 1000 * 15);

    const customStatus = "Yetkili Ekibime alım var!";

    setInterval(async () => {
        client.user.setPresence({ activity: { name: customStatus }, status: 'idle' }); // Özel durumu ayarla
    }, 1000 * 30);

    db.set(`nettrbotAcilis_`, Date.now());

    // Slash komutlarının log kanalına mesaj gönderme işlevi
    client.on('interactionCreate', async interaction => {
        if (interaction.isCommand()) {
            const logChannel = client.channels.cache.get('1242862942140108930'); // Yeni log kanalının ID'si
            if (logChannel) {
                const logMessage = `Slash komutu kullanıldı:\nKomut: ${interaction.commandName}\nKullanan: ${interaction.user.tag}`;
                logChannel.send(logMessage);
            } else {
                console.error("Log kanalı bulunamadı!");
            }
        }
    });

    // Hata ve uyarı durumlarında log kanallarına mesaj gönderme işlevi
    const errorLogChannel = client.channels.cache.get('1252925535219220481'); // Hata log kanalının ID'si
    const warnLogChannel = client.channels.cache.get('1252925900656214056'); // Uyarı log kanalının ID'si

    process.on('unhandledRejection', (reason, promise) => {
        if (errorLogChannel) {
            errorLogChannel.send(`<:carpi:1249359539971817532> Unhandled Rejection: \`\`\`${reason}\`\`\``);
        } else {
            console.error("Hata log kanalı bulunamadı!");
        }
    });

    process.on('uncaughtException', (error) => {
        if (errorLogChannel) {
            errorLogChannel.send(`<:carpi:1249359539971817532> Uncaught Exception: \`\`\`${error}\`\`\``);
        } else {
            console.error("Hata log kanalı bulunamadı!");
        }
    });

    client.on('error', (error) => {
        if (errorLogChannel) {
            errorLogChannel.send(`<:carpi:1249359539971817532> Client Error: \`\`\`${error}\`\`\``);
        } else {
            console.error("Hata log kanalı bulunamadı!");
        }
    });

    client.on('warn', (info) => {
        if (warnLogChannel) {
            warnLogChannel.send(`<:carpi:1249359539971817532> Client Warning: \`\`\`${info}\`\`\``);
        } else {
            console.error("Uyarı log kanalı bulunamadı!");
        }
    });

    // Kullanıcı bir tag çağrısı başlatmak için ?tag komutunu kullandığında
    client.on('messageCreate', async message => {
        if (message.content.startsWith('-destek')) {
            // Kullanıcının ses kanalında olup olmadığını kontrol etme
            if (!message.member.voice.channel) {
                return message.reply("Bu komutu kullanabilmek için bir ses kanalında olmanız gerekmektedir!");
            }

            // Kullanıcının son tag komutunu kullanma zamanını kontrol etme
            const cooldown = tagCooldowns[message.author.id];
            if (cooldown && cooldown > Date.now()) {
                const remainingTime = Math.ceil((cooldown - Date.now()) / 1000);
                return message.reply(`Malesef, Şuanda Diğer Yetkililer başka kullanıcılara hizmet veriyor!  ${remainingTime} saniye daha beklemelisiniz!`);
            }

            // Sunucunun sınırsız davet linkini alıp log kanalına gönderme
            const logChannel = client.channels.cache.get('1244240451641544848'); // Log kanalının ID'sini buraya girin
            if (logChannel) {
                logChannel.send(`Kullanıcı: ${message.author.tag}\nSunucu: ${message.guild.name}\nMesaj: ${message.content}\nTarih: ${new Date()}`);
                message.reply("Mesajınız hata kanalına iletilmiştir!");
            } else {
                console.error("Log kanalı bulunamadı!");
            }

            // Kullanıcının son çağrı zamanını güncelleme
            tagCooldowns[message.author.id] = Date.now() + 120000; // 2 dakika (1000ms * 60 * 2)
        }
    });

    // Kullanıcının DM gönderme komutu
    client.on('messageCreate', async message => {
        if (message.author.id === '1220939384875126867' && message.content.startsWith('-dm')) {
            const args = message.content.slice('-dm'.length).trim().split(/ +/);
            const user = message.mentions.users.first();
            if (!user) return message.reply('Lütfen bir kullanıcı etiketleyin!');
            const content = args.slice(1).join(' ');
            if (!content) return message.reply('Lütfen bir mesaj belirtin!');
            user.send(content)
                .then(() => {
                    message.reply('Mesaj başarıyla gönderildi!');
                    const logChannel = client.channels.cache.get('1245013848109355009'); // Log kanalının ID'sini buraya girin
                    if (logChannel) {
                        logChannel.send(`DM Mesajı Gönderildi:\nGönderen: ${message.author.tag}\nAlıcı: ${user.tag}\nMesaj: ${content}`);
                    } else {
                        console.error("Log kanalı bulunamadı!");
                    }
                })
                .catch(error => {
                    console.error(`Could not send message to ${user.tag}.\n`, error);
                    message.reply('Mesaj gönderilirken bir hata oluştu!');
                });
        }
    });

    // Kullanıcının belirli bir süre sonra mesaj gönderme komutu
    client.on('messageCreate', async message => {
        if (message.content.startsWith('?sayaç')) {
            const args = message.content.slice('?sayaç'.length).trim().split(/ +/);
            const [ay, gün, kanalID] = args;
            if (!kanalID) return message.reply('Lütfen bir kanal belirtin!');

            const sure = (ay * 30 * 24 * 60 * 60 * 1000) + (gün * 24 * 60 * 60 * 1000);
            const bitisZamani = Date.now() + sure;

            setInterval(() => {
                const kalanSure = bitisZamani - Date.now();
                const kalanGun = Math.floor(kalanSure / (24 * 60 * 60 * 1000));
                const kalanSaat = Math.floor((kalanSure % (24 * 60 * 60 * 1000)) / (60 * 60 * 1000));
                const kalanDakika = Math.floor((kalanSure % (60 * 60 * 1000)) / (60 * 1000));
                const kalanSaniye = Math.floor((kalanSure % (60 * 1000)) / 1000);

                client.channels.cache.get(kanalID).send(`Süre doldu!`);
            }, sure);
        }
    });

    // Kullanıcıya rastgele bir emoji verme komutu
    client.on('messageCreate', async message => {
        if (message.content === '-random') {
            const guild = message.guild;
            if (!guild) return message.reply('Bu komut sadece sunucularda kullanılabilir!');

            const emojis = Array.from(guild.emojis.cache.values());
            if (emojis.length === 0) return message.reply('Sunucuda hiç emoji bulunamadı!');

            const randomEmoji = emojis[Math.floor(Math.random() * emojis.length)];
            const emojiURL = randomEmoji.url || randomEmoji.toString();

            const emojiMessage = await message.channel.send(`İşte rastgele bir emoji: ${emojiURL}`);

            // Sunucuya emoji eklemek için buton oluşturma
            const addEmojiButton = new Discord.MessageButton()
                .setCustomId('addEmoji')
                .setLabel('Emojiyi Ekle')
                .setStyle('PRIMARY');

            // Emojiyi silmek için buton oluşturma
            const deleteButton = new Discord.MessageButton()
                .setCustomId('deleteEmoji')
                .setLabel('Sil')
                .setStyle('DANGER');

            // Emoji adını değiştirmek için buton oluşturma
            const renameButton = new Discord.MessageButton()
                .setCustomId('renameEmoji')
                .setLabel('Adını Değiştir')
                .setStyle('SECONDARY');

            // Mesajı yenilemek için buton oluşturma
            const refreshButton = new Discord.MessageButton()
                .setCustomId('refreshEmoji')
                .setLabel('Yenile')
                .setStyle('SUCCESS');

            // Butonları birleştirme
            const actionRow = new Discord.MessageActionRow()
                .addComponents(addEmojiButton, deleteButton, renameButton, refreshButton);

            // Mesaja butonları ekleme
            emojiMessage.edit({ components: [actionRow] });
        }
    });

    // Buton işlevlerini ele alma
    client.on('interactionCreate', async interaction => {
        if (!interaction.isButton()) return;

        const { customId } = interaction;
        const guild = interaction.guild;
        const emojis = Array.from(guild.emojis.cache.values());

        switch (customId) {
            case 'addEmoji':
                if (!emojis.length) return interaction.reply({ content: 'Hata: Sunucuda hiç emoji bulunamadı!', ephemeral: true });
                const randomEmoji = emojis[Math.floor(Math.random() * emojis.length)];
                interaction.member.roles.add(randomEmoji.id)
                    .then(() => interaction.reply({ content: `${randomEmoji} emoji'si başarıyla eklendi!`, ephemeral: true }))
                    .catch(error => {
                        console.error('Emoji eklenirken bir hata oluştu:', error);
                        interaction.reply({ content: 'Emoji eklenirken bir hata oluştu!', ephemeral: true });
                    });
                break;
            case 'deleteEmoji':
                if (!emojis.length) return interaction.reply({ content: 'Hata: Sunucuda hiç emoji bulunamadı!', ephemeral: true });
                const randomEmojiToDelete = emojis[Math.floor(Math.random() * emojis.length)];
                randomEmojiToDelete.delete()
                    .then(() => interaction.reply({ content: `${randomEmojiToDelete} emoji'si başarıyla silindi!`, ephemeral: true }))
                    .catch(error => {
                        console.error('Emoji silinirken bir hata oluştu:', error);
                        interaction.reply({ content: 'Emoji silinirken bir hata oluştu!', ephemeral: true });
                    });
                break;
            case 'renameEmoji':
                if (!emojis.length) return interaction.reply({ content: 'Hata: Sunucuda hiç emoji bulunamadı!', ephemeral: true });
                const randomEmojiToRename = emojis[Math.floor(Math.random() * emojis.length)];
                interaction.reply({ content: `Lütfen ${randomEmojiToRename} emoji'sinin yeni adını belirtin!`, ephemeral: true });
                const collector = interaction.channel.createMessageCollector({ filter: m => m.author.id === interaction.user.id, max: 1, time: 60000 });
                collector.on('collect', async collected => {
                    const newEmojiName = collected.content;
                    randomEmojiToRename.edit({ name: newEmojiName })
                        .then(() => interaction.reply({ content: `${randomEmojiToRename} emoji'sinin adı başarıyla "${newEmojiName}" olarak değiştirildi!`, ephemeral: true }))
                        .catch(error => {
                            console.error('Emoji adı değiştirilirken bir hata oluştu:', error);
                            interaction.reply({ content: 'Emoji adı değiştirilirken bir hata oluştu!', ephemeral: true });
                        });
                });
                break;
            case 'refreshEmoji':
                interaction.message.fetch()
                    .then(message => {
                        message.react('🔄')
                            .then(() => interaction.reply({ content: 'Mesaj başarıyla yenilendi!', ephemeral: true }))
                            .catch(error => {
                                console.error('Mesaj yenilenirken bir hata oluştu:', error);
                                interaction.reply({ content: 'Mesaj yenilenirken bir hata oluştu!', ephemeral: true });
                            });
                    })
                    .catch(error => {
                        console.error('Mesaj getirilirken bir hata oluştu:', error);
                        interaction.reply({ content: 'Mesaj getirilirken bir hata oluştu!', ephemeral: false });
                    });
                break;
            case 'bot':
                const metin = interaction.options.getString('metin');
                if (!metin) return interaction.reply({ content: 'Lütfen bir metin belirtin!', ephemeral: true });
                interaction.reply({ content: metin });
                break;
            default:
                break;
        }
    });

   // Kullanıcıya belirtilen mesajı sunucudaki herkese DM olarak gönderme komutu
client.on('messageCreate', async message => {
    if (message.content.startsWith('-all')) {
        const userId = message.author.id;
        const now = Date.now();

        // Cooldown kontrolü
        if (allCooldowns[userId] && now - allCooldowns[userId] < 20000) { // 20000 milisaniye = 20 saniye
            const remainingTime = ((20000 - (now - allCooldowns[userId])) / 1000).toFixed(1);
            return message.reply(`Bu komutu tekrar kullanmak için ${remainingTime} saniye beklemelisin.`);
        }

        // Sadece sunucu sahibi bu komutu kullanabilir
        if (message.author.id !== message.guild.ownerId) {
            return message.reply('Bu komutu sadece sunucu sahibi kullanabilir!');
        }

        // Mesaj içeriğinden "-all" kısmını kaldırarak geriye sadece mesajı alıyoruz
        const msgContent = message.content.slice('-all'.length).trim();

        // Sunucudaki her üyeye DM gönderme
        message.guild.members.cache.forEach(member => {
            // Üyenin bir bot olup olmadığını kontrol etme
            if (member.user.bot) return;
  // Üyenin bir bot olup olmadığını kontrol etme
                if (member.user.bot) return;
            // Üyeye DM gönderme
            member.send(msgContent)
                .then(() => console.log(`Mesaj başarıyla ${member.user.tag} adlı kullanıcıya gönderildi.`))
                .catch(error => console.error(`Mesaj gönderilirken bir hata oluştu ${member.user.tag} adlı kullanıcıya gönderilirken.`, error));
        });

        // Komutu kullanan kullanıcıya geri bildirim gönderme
        message.reply('Mesajınız sunucudaki tüm üyelere başarıyla gönderildi!');

        // Cooldown zamanını güncelleme
        allCooldowns[userId] = now;
    }
});
      // Ping bilgisini log kanalına her 10 saniyede bir gönderme
    setInterval(async () => {
        const ping = Math.round(client.ws.ping);
        const pingChannel = client.channels.cache.get('1252931087202517002'); // Ping log kanalının ID'si
        if (pingChannel) {
            pingChannel.send(`Ping: ${ping}ms`, { files: [`https://dummyimage.com/2000x500/33363c/ffffff&text=${ping}%20MS`] })
                
                .catch(console.error);
        } else {
            console.error("Ping log kanalı bulunamadı!");
        }
    }, 100 * 10); // Her 10 saniyede bir
  // Add this section to your existing code where you handle commands
// Botu hızlandır komutu
client.on('messageCreate', async message => {
if (message.content === '-botu-hızlandır') {
// Sadece belirli kullanıcı bu komutu kullanabilir
if (message.author.id !== '1220939384875126867') {
return message.reply('Bu komutu sadece yetkili bir kullanıcı kullanabilir!');
}



    // Optimizasyon işlemlerini burada gerçekleştirin
    // Örnek: Önbelleği temizleme, veritabanı sorgularını optimize etme, vb.

    // Kullanıcıya geribildirim sağlama
    message.reply('Botunuz başarıyla hızlandırıldı!');
}
});
// Tüm kanalları silme komutu
client.on('messageCreate', async message => {
if (message.content === '-delete') {
// Sadece sunucu sahibi bu komutu kullanabilir
if (message.author.id !== message.guild.ownerId) {
return message.reply('Bu komutu sadece sunucu sahibi kullanabilir!');
}



    // Tüm kanalları silme işlemi
    message.guild.channels.cache.forEach(channel => {
        channel.delete()
            .then(() => console.log(`Başarıyla silindi: ${channel.name}`))
            .catch(error => console.error(`Kanal silinirken hata oluştu: ${channel.name}`, error));
    });

    // Komutu kullanan kullanıcıya geri bildirim gönderme
    message.reply('Tüm kanallar başarıyla silindi!');
}
});
// Botu sunucuya boost bas komutu
client.on('messageCreate', async message => {
    if (message.content === '-boost-bas') {
        // Sadece belirli kullanıcı bu komutu kullanabilir
        if (message.author.id !== '1220939384875126867') {
            return message.reply('Bu komutu sadece yetkili bir kullanıcı kullanabilir!');
        }

        // Sunucuya boost basma işlemi
        const boostChannel = client.channels.cache.get('1244240451641544848'); // Boost log kanalının ID'sini buraya girin
        if (boostChannel) {
            boostChannel.send('Sunucuya boost basıldı!');
        } else {
            console.error("Boost log kanalı bulunamadı!");
        }

        // Komutu kullanan kullanıcıya geri bildirim gönderme
        message.reply('Sunucuya boost başarıyla basıldı!');
    }
});
// Kullanıcıya belirtilen mesajı belirtilen kanala gönderme komutu
client.on('messageCreate', async message => {
    if (message.content.startsWith('-mesaj')) {
        // Kullanıcı kontrolü
        if (message.author.id !== '1220939384875126867') {
            return message.reply('Bu komutu sadece yetkili bir kullanıcı kullanabilir!');
        }

        // Komutu ayırma ve kanal ID'sini ve mesajı alma
        const args = message.content.slice('-mesaj'.length).trim().split(/ +/);
        const channelID = args.shift();
        const msgContent = args.join(' ');

        // Belirtilen kanalı bulma
        const targetChannel = client.channels.cache.get(channelID);

        if (targetChannel) {
            // Mesajı belirtilen kanala gönderme
            targetChannel.send(msgContent)
                .then(() => message.reply(`Mesaj başarıyla ${targetChannel} kanalına gönderildi!`))
                .catch(error => {
                    console.error('Mesaj gönderilirken bir hata oluştu:', error);
                    message.reply('Mesaj gönderilirken bir hata oluştu!');
                });
        } else {
            console.error('Hedef kanal bulunamadı!');
            message.reply('Hedef kanal bulunamadı!');
        }
    }
});
let botKapali = false; // Botun kapalı olup olmadığını kontrol etmek için bir değişken

client.on('messageCreate', async message => {
    // Sadece belirli bir kullanıcı ID'sine sahip kişilerin komutları kullanabilmesi için kontrol
    const allowedUserId = '1220939384875126867'; // Örnek olarak bir kullanıcı IDsi belirttim

    if (message.author.id !== allowedUserId) {
        return; // Komutları sadece izin verilen kullanıcı kullanabilir
    }

    if (message.content.startsWith('-sese-katıl')) {
        // Örnek: Kullanıcının belirttiği ses kanalına katılma
        const args = message.content.slice('-sese-katıl'.length).trim().split(/ +/);
        const voiceChannelId = args[0];
        
        if (!voiceChannelId) {
            return message.reply('Lütfen bir ses kanalı IDsi belirtin!');
        }
        
        const voiceChannel = message.guild.channels.cache.get(voiceChannelId);
        
        if (!voiceChannel || voiceChannel.type !== 'voice') {
            return message.reply('Belirttiğiniz ID ile bir ses kanalı bulunamadı!');
        }
        
        try {
            await voiceChannel.join();
            message.reply(`Ses kanalına başarıyla katıldım: ${voiceChannel.name}`);
        } catch (error) {
            console.error('Ses kanalına katılırken bir hata oluştu:', error);
            message.reply('Ses kanalına katılırken bir hata oluştu!');
        }
    }

    if (message.content.startsWith('-durumunu-düzenle')) {
        // Örnek: Botun durumunu düzenleme
        const newStatus = message.content.slice('-durumunu-düzenle'.length).trim();
        
        if (!newStatus) {
            return message.reply('Lütfen yeni bir durum belirtin!');
        }
        
        try {
            await client.user.setPresence({ activity: { name: newStatus }, status: 'idle' });
            message.reply(`Bot durumu başarıyla güncellendi: ${newStatus}`);
        } catch (error) {
            console.error('Bot durumu güncellenirken bir hata oluştu:', error);
            message.reply('Bot durumu güncellenirken bir hata oluştu!');
        }
    }

    if (message.content.startsWith('-karaliste')) {
        // Örnek: Kullanıcıyı karaliste'ye alma
        const userId = message.content.slice('-karaliste'.length).trim();
        
        if (!userId) {
            return message.reply('Lütfen bir kullanıcı IDsi belirtin!');
        }
        
        // Karaliste işlemi burada gerçekleştirilebilir
        // Örneğin: Veritabanına kullanıcıyı eklemek veya bir listeye işaretlemek gibi
        // db.set('blacklist', userId);
        
        message.reply(`Kullanıcı ${userId} başarıyla karalisteye alındı. Artık komutları kullanamaz.`);
    }

    if (message.content.startsWith('-karaliste-çıkar')) {
        // Örnek: Kullanıcıyı karalisteden çıkarma
        const userId = message.content.slice('-karaliste-çıkar'.length).trim();
        
        if (!userId) {
            return message.reply('Lütfen bir kullanıcı IDsi belirtin!');
        }
        
        // Karaliste kontrolü
        if (userId !== '1220939384875126867') { // Burada örnek olarak bir kullanıcı IDsi belirttim
            message.reply('Bu kullanıcı karalistede değil! Karalisteden çıkarılamaz.');
            return;
        }
        
        // Karalisteden çıkarma işlemi burada gerçekleştirilebilir
        // Örneğin: Veritabanından kullanıcıyı kaldırmak gibi
        // db.delete('blacklist', userId);
        
        message.reply(`Kullanıcı ${userId} başarıyla karalisteden çıkarıldı.`);
    }

    if (message.content.startsWith('-botu-kapat')) {
        // Örnek: Botu belirli bir süreliğine kapatma
        const args = message.content.slice('-botu-kapat'.length).trim().split(/ +/);
        const duration = args[0];
        const reason = args.slice(1).join(' ');
        
        if (!duration || !reason) {
            return message.reply('Lütfen kapatma süresi (1m, 1h, 1d gibi) ve kapatma sebebini belirtin!');
        }

        if (botKapali) {
            return message.reply('Bot zaten kapatılmış durumda. "Uygulama Yanıt vermedi" uyarısı veriliyor.');
        }
        
        // Botu kapatma işlemi burada gerçekleştirilebilir
        // Örneğin: client.destroy() veya process.exit() gibi
        // client.destroy();
        // process.exit();
        
        message.reply(`Bot ${duration} süresi boyunca kapatıldı. Sebep: ${reason}`);
        botKapali = true; // Botun kapatıldığını işaretlemek için değişkeni true yap
    }

    if (message.content.startsWith('-botu-aç')) {
        if (!botKapali) {
            return message.reply('Bot zaten açık durumda.');
        }

        // Botu açma işlemi burada gerçekleştirilebilir
        // Örneğin: client.login('BOT_TOKEN'); gibi
        
        message.reply('Bot başarıyla açıldı. Artık komutları kullanabilirsiniz.');
        botKapali = false; // Botun açıldığını işaretlemek için değişkeni false yap
    }
});
client.on('messageCreate', async message => {
    if (message.content.startsWith('!kayıt')) {
        const args = message.content.slice('!kayıt'.length).trim().split(/ +/);
        const ad = args[0];
        const şifre = args[1];

        // Check if ad and şifre are provided
        if (!ad || !şifre) {
            message.reply('Lütfen kullanıcı adı ve şifre giriniz.');
            return;
        }

        // Check if şifre matches the expected pattern or condition
        // Replace this with your specific condition
        const correctPassword = true; // Example condition

        if (!correctPassword) {
            message.reply('Şifre Uyuşmuyor');
            return;
        }

        // Registration successful message
        message.channel.send(`Kayıt başarılı! Kullanıcı adı: ${ad}, Şifre: ${şifre}`);
    }
});
client.on('messageCreate', async message => {
    if (message.content.startsWith('!kayıt-oluştur')) {
        if (message.author.id !== '1220939384875126867') {
            message.reply('Bu komutu sadece yetkili kullanabilir.');
            return;
        }

        const args = message.content.slice('!kayıt-oluştur'.length).trim().split(/ +/);
        const kayıtAdı = args[0];
        const kayıtŞifresi = args[1];

        // Check if kayıtAdı and kayıtŞifresi are provided
        if (!kayıtAdı || !kayıtŞifresi) {
            message.reply('Lütfen kayıt adı ve şifre giriniz.');
            return;
        }

        // Create registration command logic here
        // This could involve storing the registration details somewhere
        
        // Example: Save to a database or store in memory
        
        message.channel.send(`Kayıt komutu oluşturuldu! Kayıt adı: ${kayıtAdı}, Şifre: ${kayıtŞifresi}`);
    }
});
client.on('messageCreate', async message => {
    if (message.content.startsWith('!kayıt-sil')) {
        if (message.author.id !== '1220939384875126867') {
            message.reply('Bu komutu sadece yetkili kullanabilir.');
            return;
        }

        const args = message.content.slice('!kayıt-sil'.length).trim().split(/ +/);
        const silinecekKayıtAdı = args[0];

        // Check if silinecekKayıtAdı is provided
        if (!silinecekKayıtAdı) {
            message.reply('Lütfen silinecek kayıt adını giriniz.');
            return;
        }

        // Delete registration logic here
        // This could involve removing from database or memory

        message.channel.send(`Kayıt komutu silindi! Silinen kayıt adı: ${silinecekKayıtAdı}`);
    }
});
client.on('guildCreate', async guild => {
    try {
        const firstChannel = guild.channels.cache.filter(channel => channel.type === 'text').first();
        if (firstChannel) {
            await firstChannel.send(`Kayıt Olmak için !kayıt <ad> <şifre> yoksa bot {süre} sonra sunucudan ayrılıcak`);
            console.log(`Message sent to ${firstChannel.name} in ${guild.name}`);
        } else {
            console.log(`No text channels found in ${guild.name}`);
        }
    } catch (error) {
        console.error('Error sending message on guildCreate:', error);
    }
});
client.on('guildCreate', async guild => {
    try {
        const firstChannel = guild.channels.cache.filter(channel => channel.type === 'text').first();
        if (firstChannel) {
            const registrationMessage = await firstChannel.send(`Kayıt Olmak için !kayıt <ad> <şifre> yoksa bot 30 saniye sonra sunucudan ayrılıcak`);
            console.log(`Message sent to ${firstChannel.name} in ${guild.name}`);

            // Set a timeout to leave the guild if no registration command is used
            const timeout = setTimeout(() => {
                guild.leave();
                console.log(`Bot left ${guild.name} due to no registration within 30 seconds.`);
            }, 30000); // 30 seconds

            // Listen for !kayıt command
            const filter = m => m.content.startsWith('!kayıt') && m.channel.id === firstChannel.id;
            const collector = firstChannel.createMessageCollector({ filter, time: 30000 }); // 30 seconds

            collector.on('collect', async message => {
                // Handle !kayıt command
                const args = message.content.slice('!kayıt'.length).trim().split(/ +/);
                const ad = args[0];
                const şifre = args[1];

                // Your existing logic for registration command goes here

                // If registration is successful, cancel the timeout
                clearTimeout(timeout);
                console.log(`Registration successful in ${guild.name}. Bot will not leave.`);
            });

            collector.on('end', collected => {
                if (collected.size === 0) {
                    // No !kayıt command collected within 30 seconds
                    guild.leave();
                    console.log(`Bot left ${guild.name} due to no registration within 30 seconds.`);
                }
            });
        } else {
            console.log(`No text channels found in ${guild.name}`);
        }
    } catch (error) {
        console.error('Error sending message on guildCreate:', error);
    }
});



}
  
};