const { Client, EmbedBuilder, PermissionsBitField } = require("discord.js");

module.exports = {
    name: "sil-kişi",
    description: '💙 Belirli bir kullanıcının mesajlarını sil!',
    type: 1,
    options: [
        {
            name: "kullanıcı",
            description: "Mesajlarını silmek istediğiniz kullanıcıyı etiketleyin.",
            type: 6, // USER type
            required: true
        },
        {
            name: "sayı",
            description: "Temizlenecek maksimum mesaj sayısını girin.",
            type: 4, // INTEGER type
            required: true
        }
    ],
    run: async (client, interaction) => {
        if (!interaction.member.permissions.has(PermissionsBitField.Flags.ManageMessages)) {
            return interaction.reply({ content: "<:carpi:1040649840394260510> | Mesajları Yönet Yetkin Yok!", ephemeral: true });
        }

        const kullanıcı = interaction.options.getUser('kullanıcı');
        const sayi = interaction.options.getInteger('sayı');

        if (sayi <= 0 || sayi > 100) {
            return interaction.reply({ content: "<:carpi:1040649840394260510> | 1 ile 100 arasında bir sayı girin!", ephemeral: true });
        }

        const fetchedMessages = await interaction.channel.messages.fetch({ limit: sayi });
        const userMessages = fetchedMessages.filter(msg => msg.author.id === kullanıcı.id);

        if (userMessages.size === 0) {
            return interaction.reply({ content: `<:carpi:1040649840394260510> | Belirtilen kullanıcıya ait mesaj bulunamadı!`, ephemeral: true });
        }

        await interaction.channel.bulkDelete(userMessages, true).catch(error => {
            console.error('Hata:', error);
            return interaction.reply({ content: `<:carpi:1040649840394260510> | Mesajları silerken bir hata oluştu!`, ephemeral: true });
        });

        interaction.reply({ content: `<:tik:1039607067729727519> | Başarıyla ${userMessages.size} adet mesajı sildim.` });
    }
};
