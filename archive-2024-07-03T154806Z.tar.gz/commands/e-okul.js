module.exports = {
    name: "eokul-not",
    description: "E Okul notları simülasyonu!",
    type: 1, // Slash komutu
    run: async (client, interaction) => {
        // 5 saniye sonra yanıt verilmesi için `editIn` kullanılmaz, doğrudan yanıt gönderilir
        const fenNotu = Math.floor(Math.random() * 91) + 10; // 10 ile 100 arası rastgele bir sayı
        const matematikNotu = Math.floor(Math.random() * 91) + 10;
        const turkceNotu = Math.floor(Math.random() * 91) + 10;
        const inkilapTarihiNotu = Math.floor(Math.random() * 91) + 10;
        const biyolojiNotu = Math.floor(Math.random() * 91) + 10;
        const kimyaNotu = Math.floor(Math.random() * 91) + 10;

        await interaction.reply({
            content: `E Okul Notları:

Fen Notun: ${fenNotu}
Matematik Notun: ${matematikNotu}
Türkçe Notun: ${turkceNotu}
İnkılap Tarihi Notun: ${inkilapTarihiNotu}
Biyoloji Notun: ${biyolojiNotu}
Kimya Notun: ${kimyaNotu}`,
            ephemeral: true // Yanıtın sadece kullanıcı tarafından görünmesi
        });
    }
};
