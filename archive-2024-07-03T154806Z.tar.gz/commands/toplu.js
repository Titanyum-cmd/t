const { Permissions } = require("discord.js");
const db = require("croxydb");

module.exports = {
    name: "toplu-rol-ver",
    description: 'Birine Rol Verir!',
    type: 1, // Slash komutu
    options: [
        {
            name: "rol",
            description: "Lütfen bir rol seçin!",
            type: 8, // Rol tipi
            required: true
        },
    ],
    run: async (client, interaction) => {
        if (!interaction.member.permissions.has(Permissions.FLAGS.MANAGE_ROLES)) {
            return interaction.reply({ content: "<:carpi:1249359539971817532> | Rolleri Yönet yetkiniz yok!", ephemeral: true });
        }

        const rol = interaction.options.getRole('rol');
        const members = interaction.guild.members.cache.filter(member => !member.user.bot);

        let successCount = 0;
        let failureCount = 0;

        for (const member of members.values()) {
            try {
                await member.roles.add(rol);
                successCount++;
            } catch (err) {
                console.error(`Rol eklenirken hata oluştu ${member.user.tag}:`, err);
                failureCount++;
            }
        }

        interaction.reply({ content: `<:tik:1039607067729727519> | Başarıyla ${successCount} üyeye <@&${rol.id}> rolü verildi! ${failureCount} üyeye rol verilemedi.` });
    }
};

module.exports = {
    name: "toplu-rol-kaldır",
    description: 'Birinden Rol Kaldırır!',
    type: 1, // Slash komutu
    options: [
        {
            name: "rol",
            description: "Lütfen bir rol seçin!",
            type: 8, // Rol tipi
            required: true
        },
    ],
    run: async (client, interaction) => {
        if (!interaction.member.permissions.has(Permissions.FLAGS.MANAGE_ROLES)) {
            return interaction.reply({ content: "<:carpi:1249359539971817532> | Rolleri Yönet yetkiniz yok!", ephemeral: true });
        }

        const rol = interaction.options.getRole('rol');
        const members = interaction.guild.members.cache.filter(member => member.roles.cache.has(rol.id) && !member.user.bot);

        let successCount = 0;
        let failureCount = 0;

        for (const member of members.values()) {
            try {
                await member.roles.remove(rol);
                successCount++;
            } catch (err) {
                console.error(`Rol kaldırılırken hata oluştu ${member.user.tag}:`, err);
                failureCount++;
            }
        }

        interaction.reply({ content: `<:tik:1039607067729727519> | Başarıyla ${successCount} üyeden <@&${rol.id}> rolü kaldırıldı! ${failureCount} üyeden rol kaldırılamadı.` });
    }
};
