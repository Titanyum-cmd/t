const { Client, EmbedBuilder, PermissionsBitField } = require("discord.js");
const Discord = require("discord.js")
module.exports = {
  name: "say",
  description: "💙 Sunucuda kaç üye olduğunu gösterir.",
  type: 1,
  options: [],

  run: async(client, interaction) => {

    const memberCount = interaction.guild.members.cache.filter((member) => !member.user.bot).size || 0
    const fakeMemberCount = interaction.guild.members.cache.filter((member) => new Date().getTime() - client.users.cache.get(member.id).createdAt.getTime() < 1296000000).size || 0
    const botCount = interaction.guild.members.cache.filter((member) => member.user.bot).size || 0
    const permissionsMemberCount = interaction.guild.members.cache.filter((member) => member.permissions.has(PermissionsBitField.Flags.Administrator)).size || 0
	        const onlinekişi = interaction.guild.members.cache.filter(o => !o.user.bot && o.presence && o.presence.status === 'online').size
        const boştakişi = interaction.guild.members.cache.filter(o => !o.user.bot && o.presence && o.presence.status === 'idle').size
        const retmekişi = interaction.guild.members.cache.filter(o => !o.user.bot && o.presence && o.presence.status === 'dnd').size

    const embed = new EmbedBuilder()
    .setTitle('NETTR Bot')
    .setThumbnail(`${interaction.guild.iconURL({ dynamic: true })}`)
    .setFooter({text: interaction.user.tag+" İstedi."})
    .setDescription(`<:member:1255778496911773756> | Toplam Üye: **${interaction.guild.memberCount}** ( Çevrimiçi: **${onlinekişi}** | Boşta: **${boştakişi}** | Rahatsız Etmeyin **${retmekişi}** )\n<:tik:1246412431882850334> | Gerçek: **${memberCount}**\n<:uyar:1255780736188026951> | Sahte: **${fakeMemberCount}**\n<:Bot:1254783165579657366> | Bot: **${botCount}**\n<:guardian:1254782798678458449> | Yönetici Yetkili: **${permissionsMemberCount}**`)
    .setColor("Random")
interaction.reply({embeds: [embed]})
  }  

};