const { AttachmentBuilder, EmbedBuilder, PermissionsBitField } = require("discord.js");

module.exports = {
  name: "level-log",
  description: "Level logu ayarlarsın!",
  type: 1,
  options: [
    {
      name: "kanal",
      description: "Level log kanalını ayarlarsın!",
      type: 7,
      required: true,
      channel_types: [0]
    },
  ],

  run: async (client, interaction, db) => {
    const { guild, options } = interaction;

    // Check if the leveling system is enabled
   

    // Check if the user has the 'ManageChannels' permission
    if (!interaction.member.permissions.has(PermissionsBitField.Flags.ManageChannels)) {
      return interaction.reply({ content: " <:dikkat:1239941376720896083> | Kanalları Yönet Yetkin Yok!", ephemeral: true });
    }

    const kanal2 = options.getChannel('kanal');
    db.set(`level_log_${guild.id}`, kanal2.id);
    interaction.reply(`<:tik:1239942411610751116> | Level log kanalı <#${kanal2.id}> olarak ayarlandı!`);
  }
};
