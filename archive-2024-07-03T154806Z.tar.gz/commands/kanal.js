const { Client, EmbedBuilder, PermissionsBitField } = require("discord.js");
const Discord = require("discord.js");

module.exports = {
  name: "kanal",
  description: "💙 Kanalı mesaj gönderimine açar!",
  type: 1,
  options: [
    {
      name: "adı",
      description: "Yeni kanalın adı.",
      type: 3, // STRING type
      required: true
    },
    {
      name: "mesaj-gönderimi",
      description: "Kanalda mesaj gönderimine izin verilsin mi?",
      type: 3, // STRING type
      required: true,
      choices: [
        { name: "Mesaj Gönderilemesin", value: "false" },
        { name: "Mesaj Gönderilebilsin", value: "true" }
      ]
    },
    {
      name: "gizlilik",
      description: "Kanal gizli mi olacak?",
      type: 3, // STRING type
      required: true,
      choices: [
        { name: "Gizli", value: "private" },
        { name: "Herkese Açık", value: "public" }
      ]
    }
  ],

  run: async (client, interaction) => {
    if (!interaction.member.permissions.has(PermissionsBitField.Flags.ManageChannels)) {
      return interaction.reply({ content: "<:dikkat:1239941376720896083> | Kanalları yönet yetkin yok!", ephemeral: true });
    }

    const name = interaction.options.getString("adı");
    const sendMessages = interaction.options.getString("mesaj-gönderimi") === "true";
    const privacy = interaction.options.getString("gizlilik");

    const channelOptions = {
      name: name,
      permissionOverwrites: []
    };

    if (privacy === "private") {
      channelOptions.permissionOverwrites.push({
        id: interaction.guild.id,
        deny: [PermissionsBitField.Flags.ViewChannel]
      });
    } else {
      channelOptions.permissionOverwrites.push({
        id: interaction.guild.id,
        allow: [PermissionsBitField.Flags.ViewChannel]
      });
    }

    channelOptions.permissionOverwrites.push({
      id: interaction.guild.id,
      allow: sendMessages ? [PermissionsBitField.Flags.SendMessages] : [],
      deny: sendMessages ? [] : [PermissionsBitField.Flags.SendMessages]
    });

    try {
      const newChannel = await interaction.guild.channels.create(channelOptions);
      interaction.reply({ content: `<:tik:1239942411610751116> | Kanal başarılı bir şekilde oluşturuldu: <#${newChannel.id}>` });
    } catch (error) {
      console.error(error);
      interaction.reply({ content: "Bir hata oluştu. Lütfen tekrar deneyin.", ephemeral: true });
    }
  }
};
