const { Permissions } = require("discord.js");

module.exports = {
  name: "kanal-sil",
  description: "Belirtilen kanalı siler.",
  type: 1,
  options: [{
    name: "kanal",
    description: "Silinecek kanalı belirtin.",
    type: 7,
    required: true
  }],

  run: async (client, interaction) => {
    // Kullanıcı kanalları yönetme yetkisine sahip değilse, cevap verilir ve işlem sonlandırılır.
    if (!interaction.member.permissions.has(Permissions.FLAGS.MANAGE_CHANNELS))
      return interaction.reply({ content: "<:dikkat:1239941376720896083> | Kanalları yönetme yetkiniz yok!", ephemeral: true });

    // Silinecek kanal alınır.
    const channel = interaction.options.getChannel("kanal");

    // Kanalın var olup olmadığı kontrol edilir.
    if (!channel)
      return interaction.reply({ content: "<:dikkat:1239941376720896083> | Geçerli bir kanal belirtmelisiniz!", ephemeral: true });

    // Kanal silinir.
    channel.delete()
      .then(() => {
        interaction.reply({ content: `<:tik:1239942411610751116> | ${channel.name} kanalı başarıyla silindi!` });
      })
      .catch((error) => {
        console.error("Kanal silinirken bir hata oluştu:", error);
        interaction.reply({ content: "<:dikkat:1239941376720896083> | Kanal silinirken bir hata oluştu.", ephemeral: true });
      });
  }
};
