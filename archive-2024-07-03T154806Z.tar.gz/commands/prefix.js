const { Client, EmbedBuilder } = require("discord.js");
const Discord = require('discord.js');
const db = require("croxydb");
const moment = require("moment");
require("moment-duration-format");

module.exports = {
  name: "prefix",
  description: "Prefix gösterir",
  type: 1,
  options: [],

  run: async(client, interaction) => {
    // İlanları veritabanından çekmek için bir işlem yapılmalıdır.
    // Örneğin, veritabanından kullanıcının ilanlarını alabilir ve bu ilanları bir embed içinde gösterebilirsiniz.

    // Örnek veritabanı sorgusu:
    let userItems = db.get(`userItems_${interaction.user.id}`); // Kullanıcının ilanlarını içeren bir dizi alınır. Bu veriyi veritabanınıza uygun şekilde düzenlemelisiniz.

    // Eğer kullanıcının ilanı yoksa veya ilanları boşsa bir mesaj gönderilir.
    if (!userItems || userItems.length === 0) {
      return interaction.reply(`**> <:carpi:1249359539971817532> Bu Komutlar Bakımdadır** Daha Fazla Bilgi için [__Destek Sunucusu__](https://discord.gg/q3XuveSz63)`);
    }


  
  }
};
