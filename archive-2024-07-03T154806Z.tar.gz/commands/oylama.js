const { Client, EmbedBuilder, PermissionsBitField, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");
const db = require("croxydb");

module.exports = {
  name: "oylama",
  description: "💙 Oylama Yaparsın!",
  type: 1,
  options: [
    {
      name: "yazı",
      description: "Oylama Seçeneğini Gir!",
      type: 3,
      required: true
    },
  ],

  run: async (client, interaction) => {
    if (!interaction.member.permissions.has(PermissionsBitField.Flags.ManageNicknames)) {
      return interaction.reply({ content: "<:dikkat:1239941376720896083> | İsimleri Yönet Yetkin Yok!", ephemeral: true });
    }

    const yazı = interaction.options.getString('yazı');

    const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setStyle(ButtonStyle.Success)
          .setLabel("(0) Evet")
          .setEmoji("922176863911149660")
          .setCustomId("evetoylama_everyone"),
        new ButtonBuilder()
          .setStyle(ButtonStyle.Danger)
          .setLabel("(0) Hayır")
          .setEmoji("922176863881797693")
          .setCustomId("hayıroylama_everyone")
      );

    const embed = new EmbedBuilder()
      .setTitle("Oylama!")
      .setDescription("> " + yazı)
      .addFields({ name: 'Evet Oy ver', value: `> Evet oyu vermek için **Evet** butonuna tıklayın.`, inline: false })
      .addFields({ name: 'Hayır Oy ver', value: `> Hayır oyu vermek için **Hayır** butonuna tıklayın.`, inline: false })
      .setColor("Random");

    const message = await interaction.reply({ embeds: [embed], components: [row], fetchReply: true });

    const filter = (i) => i.customId === 'evetoylama_everyone' || i.customId === 'hayıroylama_everyone';
    const collector = message.createMessageComponentCollector({ filter, time: 60000 });

    let evetCount = 0;
    let hayirCount = 0;
    const votedUsers = new Set();

    collector.on('collect', async (i) => {
      if (votedUsers.has(i.user.id)) {
        return i.reply({ content: "Zaten oy verdiniz!", ephemeral: true });
      }
      votedUsers.add(i.user.id);

      if (i.customId === 'evetoylama_everyone') {
        evetCount++;
        const evetButton = row.components[0];
        evetButton.setLabel(`(${evetCount}) Evet`);
      } else if (i.customId === 'hayıroylama_everyone') {
        hayirCount++;
        const hayirButton = row.components[1];
        hayirButton.setLabel(`(${hayirCount}) Hayır`);
      }

      await i.update({ components: [row] });
    });

    collector.on('end', () => {
      const finalEmbed = new EmbedBuilder()
        .setTitle("Oylama Bitti!")
        .setDescription(`Oylama sona erdi.\n\n**Sonuçlar:**\nEvet: ${evetCount}\nHayır: ${hayirCount}`)
        .setColor("Random");

      interaction.editReply({ embeds: [finalEmbed], components: [] });
    });
  }
};
