const { Permissions } = require("discord.js");

module.exports = {
    name: "top",
    description: 'Botun ekli olduğu sunucunun sırasını öğrenir!',
    type: 1, // Slash komutu
    run: async (client, interaction) => {
        if (!interaction.member.permissions.has(Permissions.FLAGS.ADMINISTRATOR)) {
            return interaction.reply({ content: "<:carpi:1249359539971817532> | Bu komutu kullanmak için Yönetici yetkiniz olmalı!", ephemeral: true });
        }

        const guilds = client.guilds.cache.sort((a, b) => b.memberCount - a.memberCount);
        const botGuildIndex = guilds.findIndex(guild => guild.id === interaction.guildId);

        interaction.reply({ content: `Sunucunuzun botun ekli olduğu sunucular arasındaki sırası: ${botGuildIndex + 1}` });
    }
};
