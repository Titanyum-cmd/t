const { Client, EmbedBuilder } = require("discord.js");
const Discord = require('discord.js');
const db = require("croxydb");
const moment = require("moment");
require("moment-duration-format");

module.exports = {
  name: "mağaza",
  description: "İlanlarınızı gösterir.",
  type: 1,
  options: [],

  run: async(client, interaction) => {
    // İlanları veritabanından çekmek için bir işlem yapılmalıdır.
    // Örneğin, veritabanından kullanıcının ilanlarını alabilir ve bu ilanları bir embed içinde gösterebilirsiniz.

    // Örnek veritabanı sorgusu:
    let userItems = db.get(`userItems_${interaction.user.id}`); // Kullanıcının ilanlarını içeren bir dizi alınır. Bu veriyi veritabanınıza uygun şekilde düzenlemelisiniz.

    // Eğer kullanıcının ilanı yoksa veya ilanları boşsa bir mesaj gönderilir.
    if (!userItems || userItems.length === 0) {
      return interaction.reply("GOOGLE HARİTALAR 4 YORUM [TIKLA!](https://www.itemsatis.com/google-business-yorum/google-4-yorum-haritalar-2707260.html)");
      return interaction.reply("DİSCORD SUNUCU KOPYALAMA [TIKLA!](https://www.itemsatis.com/discord/discord-sunucu-kopyalama-2702887.html) ");
    }


  
  }
};
