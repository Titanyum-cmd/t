const { EmbedBuilder } = require("discord.js");

module.exports = {
  name: "level-sıralaması",
  description: "💙 Sunucunun level sıralamasını görüntüleyin.",
  type: 1,
  options: [],

  run: async (client, interaction, db) => {
    const { user, guild } = interaction;

    // Check if the leveling system is enabled
  

    let sayi = 1;

    const usersWithLevels = client.users.cache.filter(x => (db.fetch(`levelPos_${x.id}${guild.id}`)) || 0)
      .sort((x, y) => (db.fetch(`levelPos_${y.id}${guild.id}`) || 0) - (db.fetch(`levelPos_${x.id}${guild.id}`) || 0))
      .map((x) => {
        return `${sayi++}. <@${x.id}> **|** ${db.fetch(`levelPos_${x.id}${guild.id}`) || 0} Seviye`;
      });

    const embed = new EmbedBuilder()
      .setDescription(usersWithLevels.slice(0, 10).join("\n"))
      .setColor("#00FFFF")
      .setTitle("Sunucu Level Sıralaması");

    return interaction.reply({ embeds: [embed] });
  }
};
